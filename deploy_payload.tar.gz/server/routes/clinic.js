const express = require('express');
const router = express.Router();
const clinicController = require('../controllers/clinicController');
const { verifyToken } = require('../middleware/auth');

router.use(verifyToken);

router.get('/settings', clinicController.getSettings);
router.put('/settings', clinicController.updateSettings);
router.post('/translate', clinicController.translateText);
router.post('/parse-sentence', clinicController.parseSentence);

module.exports = router;
