const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyToken } = require('../middleware/auth');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/login/verify-otp', authController.verifyLoginOTP);
router.get('/me', verifyToken, authController.getMe);
router.post('/forgot-password', authController.forgotPassword);
router.post('/verify-otp', authController.verifyOTP);
router.post('/reset-password', authController.resetPassword);

// Doctor Passcode Lock routes
router.post('/verify-passcode', verifyToken, authController.verifyPasscode);
router.post('/forgot-passcode', verifyToken, authController.forgotPasscode);
router.post('/reset-passcode', verifyToken, authController.resetPasscode);

module.exports = router;
