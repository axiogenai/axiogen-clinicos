const { CasePaper, Patient, Queue, AuditLog } = require('../models');
const { Op } = require('sequelize');

exports.getCasePapers = async (req, res, next) => {
  try {
    const clinicId = req.user?.clinicId || 1;
    const { patientId } = req.query;
    const where = { clinicId };

    if (patientId) where.patientId = patientId;

    const casePapers = await CasePaper.findAll({
      where,
      order: [['created_at', 'DESC']]
    });
    res.json(casePapers);
  } catch (err) {
    next(err);
  }
};

exports.getCasePaper = async (req, res, next) => {
  try {
    const casePaper = await CasePaper.findByPk(req.params.id);
    if (!casePaper) return res.status(404).json({ error: 'Case paper not found' });
    res.json(casePaper);
  } catch (err) {
    next(err);
  }
};

exports.createCasePaper = async (req, res, next) => {
  try {
    const clinicId = req.user?.clinicId || 1;
    const {
      patientId,
      queueId,
      templateId,
      date,
      complaint,
      pastHistory,
      allergies,
      followUpDate,
      medicines,
      investigationsAdvised,
      counsellingDone,
      status
    } = req.body;

    if (!patientId) return res.status(400).json({ error: 'Patient ID required' });

    // Verify or resolve valid patientId
    let targetPatientId = patientId;
    const existingPatient = await Patient.findByPk(patientId);
    if (!existingPatient) {
      const anyPatient = await Patient.findOne({ where: { clinicId } });
      if (anyPatient) targetPatientId = anyPatient.id;
    }

    const casePaperDate = date || new Date().toISOString().split('T')[0];

    const casePaper = await CasePaper.create({
      clinicId,
      patientId: targetPatientId,
      doctorId: req.user?.id || 1,
      queueId: queueId || null,
      templateId: templateId || null,
      date: casePaperDate,
      complaint: complaint || '',
      pastHistory: pastHistory || '',
      allergies: allergies || '',
      followUpDate: followUpDate || '',
      medicines: medicines || [],
      investigationsAdvised: investigationsAdvised || [],
      counsellingDone: counsellingDone || [],
      status: status || 'completed'
    });

    // Mark matching queue item status as completed in database
    await Queue.update(
      { status: 'completed' },
      {
        where: {
          clinicId,
          [Op.or]: [
            queueId ? { queueId } : null,
            targetPatientId ? { patientId: targetPatientId } : null,
            req.body.patientName ? { name: req.body.patientName } : null
          ].filter(Boolean)
        }
      }
    );

    // Sync CasePaper details into OpdRegister
    try {
      const { OpdRegister, Patient } = require('../models');
      const pat = targetPatientId ? await Patient.findByPk(targetPatientId) : null;
      const reg = await OpdRegister.findOne({
        where: {
          clinicId,
          date: casePaperDate,
          [Op.or]: [
            queueId ? { queueId } : null,
            targetPatientId ? { patientId: targetPatientId } : null
          ].filter(Boolean)
        }
      });

      if (reg) {
        await reg.update({
          complaint: complaint || reg.complaint,
          diagnosis: pastHistory || reg.diagnosis,
          medicines: medicines || reg.medicines,
          investigations: investigationsAdvised || reg.investigations,
          counselling: counsellingDone || reg.counselling,
          followUpDate: followUpDate || reg.followUpDate,
          status: 'completed'
        });
      } else {
        const [yStr, mStr, dStr] = casePaperDate.split('-');
        await OpdRegister.create({
          clinicId,
          date: casePaperDate,
          year: parseInt(yStr, 10),
          month: parseInt(mStr, 10),
          day: parseInt(dStr, 10),
          queueId: queueId || `OPD-${casePaperDate.replace(/-/g, '')}-001`,
          patientId: targetPatientId || null,
          patientName: pat?.name || 'Patient',
          age: pat?.age || 0,
          gender: pat?.gender || 'M',
          phone: pat?.phone || '',
          village: pat?.village || '',
          complaint: complaint || '',
          diagnosis: pastHistory || '',
          medicines: medicines || [],
          investigations: investigationsAdvised || [],
          counselling: counsellingDone || [],
          followUpDate: followUpDate || '',
          status: 'completed'
        });
      }
    } catch (e) {
      console.warn('OpdRegister case paper sync notice:', e.message);
    }

    try {
      await AuditLog.create({
        clinicId,
        userId: req.user?.id || 1,
        action: 'create_case_paper',
        entityType: 'case_paper',
        entityId: String(casePaper.id),
        details: { patientId: targetPatientId }
      });
    } catch {
      // Audit log optional
    }

    res.status(201).json(casePaper);
  } catch (err) {
    next(err);
  }
};

exports.updateCasePaper = async (req, res, next) => {
  try {
    const casePaper = await CasePaper.findByPk(req.params.id);
    if (!casePaper) return res.status(404).json({ error: 'Case paper not found' });

    await casePaper.update(req.body);
    res.json(casePaper);
  } catch (err) {
    next(err);
  }
};

exports.getPatientHistory = async (req, res, next) => {
  try {
    const { patientId } = req.params;
    const history = await CasePaper.findAll({
      where: { patientId },
      order: [['date', 'DESC']]
    });
    res.json(history);
  } catch (err) {
    next(err);
  }
};
